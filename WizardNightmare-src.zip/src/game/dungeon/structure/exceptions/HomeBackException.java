package game.dungeon.structure.exceptions;

public class HomeBackException extends Throwable {
}
