package game.dungeon.structure.exceptions;

public class HomeNotEnoughSingaException extends Exception {
}
