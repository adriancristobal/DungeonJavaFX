package game.dungeon.structure.exceptions;

public class RoomCrystalEmptyException extends Throwable {
}
