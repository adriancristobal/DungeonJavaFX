package game.dungeon.object.exceptions;

/**
 * The store is full
 */

public class ContainerFullException extends Throwable {
}
