package game.dungeon.object.exceptions;

public class ContainerErrorException extends Throwable {
}
