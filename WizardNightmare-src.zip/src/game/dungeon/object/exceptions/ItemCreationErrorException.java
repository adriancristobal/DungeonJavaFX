package game.dungeon.object.exceptions;

public class ItemCreationErrorException extends Throwable {
}
