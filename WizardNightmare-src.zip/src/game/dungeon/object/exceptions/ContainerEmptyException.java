package game.dungeon.object.exceptions;

public class ContainerEmptyException extends Throwable {
}
