package game.dungeon.object.exceptions;

public class ContainerInvalidExchangeException extends Throwable {
}
