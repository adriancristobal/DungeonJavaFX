package game.dungeon.object.exceptions;

public class ContainerUnacceptedItemException extends Throwable {
}
