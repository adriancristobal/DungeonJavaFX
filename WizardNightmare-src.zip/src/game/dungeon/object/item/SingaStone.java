package game.dungeon.object.item;

import game.dungeon.Domain;

public class SingaStone extends Item{

    public SingaStone(int s, int m) {
        super(Domain.NONE, 0, s, m);
    }
}
