package game.dungeon;

public interface Attack {
    public int getAttackValue();
}
