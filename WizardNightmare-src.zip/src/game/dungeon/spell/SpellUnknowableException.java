package game.dungeon.spell;

public class SpellUnknowableException extends Throwable {
}
