package game.util;

public class ValueOverMaxException extends Throwable {
}
