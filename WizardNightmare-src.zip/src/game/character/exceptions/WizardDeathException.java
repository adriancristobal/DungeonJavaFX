package game.character.exceptions;

public class WizardDeathException extends Throwable {
}
