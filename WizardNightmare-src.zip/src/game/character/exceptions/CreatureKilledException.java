package game.character.exceptions;

public class CreatureKilledException extends Throwable {
}
