package game.character.exceptions;

public class WizardSpellKnowedException extends Throwable {
}
