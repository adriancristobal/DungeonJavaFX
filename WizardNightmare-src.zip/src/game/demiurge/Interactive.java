package game.demiurge;

public interface Interactive {

    void configure();

    void start();
}
